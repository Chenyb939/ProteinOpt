# -*- coding: utf-8 -*-
import os
import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *

BASE_DIR =os.path.dirname(os.path.realpath(sys.argv[0]))
class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(900, 700)
        
        self.actionPMS = QAction(MainWindow)
        self.actionPMS.setObjectName(u"actionPMS")
        self.actionVIP = QAction(MainWindow)
        self.actionVIP.setObjectName(u"actionVIP")
        self.actionSuper = QAction(MainWindow)
        self.actionSuper.setObjectName(u"actionSuper")
        self.actionMS = QAction(MainWindow)
        self.actionMS.setObjectName(u"actionMS")
        self.actionHome = QAction(MainWindow)
        self.actionHome.setObjectName(u"actionHome")
        self.actionAbout = QAction(MainWindow)
        self.actionAbout.setObjectName(u"actionAbout")
        self.actionWork = QAction(MainWindow)
        self.actionWork.setObjectName(u"actionWork")
        self.actionContact = QAction(MainWindow)
        self.actionContact.setObjectName(u"actionContact")
        self.actionSetting = QAction(MainWindow)
        self.actionSetting.setObjectName(u"actionSetting")

        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")

        self.proteinOptLabel = QLabel(self.centralwidget)
        self.proteinOptLabel.setObjectName(u"proteinOptLabel")
        self.proteinOptLabel.setGeometry(QRect(0, 0, 900, 50))
        self.proteinOptLabel.setAlignment(Qt.AlignCenter)
        self.proteinOptLabel.setStyleSheet(u"background-color: rgba(0, 0, 0, 0); color: rgb(55, 127, 170); font-size: 24px; font-weight: bold;")
        self.proteinOptLabel.setText("ProteinOpt: Protein Stability Optimization Tool")

        self.widget = QWidget(self.centralwidget)

        self.widget.setObjectName(u"widget")
        self.widget.setGeometry(QRect(50, 50, 800, 600))
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHeightForWidth(self.widget.sizePolicy().hasHeightForWidth())
        self.widget.setSizePolicy(sizePolicy)
        self.gridLayout = QGridLayout(self.widget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.VIPButton = QPushButton(self.widget)
        self.VIPButton.setObjectName(u"VIPButton")
        self.VIPButton.setFixedHeight(30)
        sizePolicy1 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        sizePolicy1.setHeightForWidth(self.VIPButton.sizePolicy().hasHeightForWidth())
        self.VIPButton.setSizePolicy(sizePolicy1)
        self.loadAndSetStyle(self.VIPButton, f'{BASE_DIR}/utils/styles_b.qss')

        self.gridLayout.addWidget(self.VIPButton, 1, 2, 1, 1)

        self.Superlabel = QLabel(self.widget)
        self.Superlabel.setObjectName(u"Superlabel")
        sizePolicy2 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy2.setHeightForWidth(self.Superlabel.sizePolicy().hasHeightForWidth())
        self.Superlabel.setSizePolicy(sizePolicy2)
        self.Superlabel.setPixmap(QPixmap(f"{BASE_DIR}/utils/su.png"))
        self.Superlabel.setScaledContents(True)

        self.gridLayout.addWidget(self.Superlabel, 3, 0, 1, 1)

        self.SuperButton = QPushButton(self.widget)
        self.SuperButton.setObjectName(u"SuperButton")
        self.SuperButton.setFixedHeight(30)
        sizePolicy1.setHeightForWidth(self.SuperButton.sizePolicy().hasHeightForWidth())
        self.SuperButton.setSizePolicy(sizePolicy1)
        self.loadAndSetStyle(self.SuperButton,f'{BASE_DIR}/utils/styles_b.qss')

        self.gridLayout.addWidget(self.SuperButton, 4, 0, 1, 1)

        self.horizontalSpacer = QSpacerItem(30, 20, QSizePolicy.Fixed, QSizePolicy.Minimum)

        self.gridLayout.addItem(self.horizontalSpacer, 0, 1, 1, 1)

        self.MSButton = QPushButton(self.widget)
        self.MSButton.setObjectName(u"MSButton")
        self.MSButton.setFixedHeight(30)
        sizePolicy1.setHeightForWidth(self.MSButton.sizePolicy().hasHeightForWidth())
        self.MSButton.setSizePolicy(sizePolicy1)
        self.loadAndSetStyle(self.MSButton, f'{BASE_DIR}/utils/styles_b.qss')

        self.gridLayout.addWidget(self.MSButton, 4, 2, 1, 1)

        self.PSMButton = QPushButton(self.widget)
        self.PSMButton.setObjectName(u"PSMButton")
        self.PSMButton.setFixedHeight(30)
        sizePolicy1.setHeightForWidth(self.PSMButton.sizePolicy().hasHeightForWidth())
        self.PSMButton.setSizePolicy(sizePolicy1)
        self.loadAndSetStyle(self.PSMButton, f'{BASE_DIR}/utils/styles_b.qss')

        self.gridLayout.addWidget(self.PSMButton, 1, 0, 1, 1)

        self.verticalSpacer = QSpacerItem(40, 20, QSizePolicy.Minimum, QSizePolicy.Fixed)

        self.gridLayout.addItem(self.verticalSpacer, 2, 0, 1, 1)

        self.VIPlabel = QLabel(self.widget)
        self.VIPlabel.setObjectName(u"VIPlabel")
        sizePolicy2.setHeightForWidth(self.VIPlabel.sizePolicy().hasHeightForWidth())
        self.VIPlabel.setSizePolicy(sizePolicy2)
        self.VIPlabel.setPixmap(QPixmap(f"{BASE_DIR}/utils/vip.png"))
        self.VIPlabel.setScaledContents(True)

        self.gridLayout.addWidget(self.VIPlabel, 0, 2, 1, 1)

        self.PSMlabel = QLabel(self.widget)
        self.PSMlabel.setObjectName(u"PSMlabel")
        sizePolicy2.setHeightForWidth(self.PSMlabel.sizePolicy().hasHeightForWidth())
        self.PSMlabel.setSizePolicy(sizePolicy2)
        self.PSMlabel.setPixmap(QPixmap(f'{BASE_DIR}/utils/pms.png'))
        self.PSMlabel.setScaledContents(True)

        self.gridLayout.addWidget(self.PSMlabel, 0, 0, 1, 1)

        self.MSlabel = QLabel(self.widget)
        self.MSlabel.setObjectName(u"MSlabel")
        sizePolicy2.setHeightForWidth(self.MSlabel.sizePolicy().hasHeightForWidth())
        self.MSlabel.setSizePolicy(sizePolicy2)
        self.MSlabel.setPixmap(QPixmap(f'{BASE_DIR}/utils/m.png'))
        self.MSlabel.setScaledContents(True)

        self.gridLayout.addWidget(self.MSlabel, 3, 2, 1, 1)

        self.gridLayout.setRowStretch(0, 5)
        self.gridLayout.setRowStretch(1, 3)
        self.gridLayout.setRowStretch(2, 1)
        self.gridLayout.setRowStretch(3, 5)
        self.gridLayout.setRowStretch(4, 3)
        self.gridLayout.setColumnStretch(0, 5)
        self.gridLayout.setColumnStretch(1, 1)
        self.gridLayout.setColumnStretch(2, 5)
        self.gridLayout.setColumnMinimumWidth(0, 5)
        self.gridLayout.setColumnMinimumWidth(1, 1)
        self.gridLayout.setColumnMinimumWidth(2, 5)
        self.gridLayout.setRowMinimumHeight(0, 5)
        self.gridLayout.setRowMinimumHeight(1, 3)
        self.gridLayout.setRowMinimumHeight(2, 1)
        self.gridLayout.setRowMinimumHeight(3, 5)
        self.gridLayout.setRowMinimumHeight(4, 3)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 800, 22))
        self.menuHome = QMenu(self.menubar)
        self.menuHome.setObjectName(u"menuHome")
        self.menuAbout = QMenu(self.menubar)
        self.menuAbout.setObjectName(u"menuAbout")
        self.menuSubmit = QMenu(self.menubar)
        self.menuSubmit.setObjectName(u"menuSubmit")
        self.menuWorkspace = QMenu(self.menubar)
        self.menuWorkspace.setObjectName(u"menuWorkspace")
        self.menuContact = QMenu(self.menubar)
        self.menuContact.setObjectName(u"menuContact")
        self.menuSetting = QMenu(self.menubar)
        self.menuSetting.setObjectName(u"menuSetting")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)
        QWidget.setTabOrder(self.PSMButton, self.VIPButton)
        QWidget.setTabOrder(self.VIPButton, self.SuperButton)
        QWidget.setTabOrder(self.SuperButton, self.MSButton)


        self.menubar.addAction(self.menuHome.menuAction())
        self.menubar.addAction(self.menuAbout.menuAction())
        self.menubar.addAction(self.menuSubmit.menuAction())
        self.menubar.addAction(self.menuWorkspace.menuAction())
        self.menubar.addAction(self.menuContact.menuAction())
        self.menubar.addAction(self.menuSetting.menuAction())

        self.menuHome.addAction(self.actionHome)
        self.menuAbout.addAction(self.actionAbout)
        self.menuWorkspace.addAction(self.actionWork)
        self.menuContact.addAction(self.actionContact)
        self.menuSetting.addAction(self.actionSetting)
        self.menuSubmit.addAction(self.actionPMS)
        self.menuSubmit.addAction(self.actionVIP)
        self.menuSubmit.addAction(self.actionSuper)
        self.menuSubmit.addAction(self.actionMS)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"ProteinOpt", None))
        self.proteinOptLabel.setToolTip(QCoreApplication.translate("MainWindow", u"ProteinOpt: Protein Stability Optimization Tool", None))
        self.actionPMS.setText(QCoreApplication.translate("MainWindow", u"Point Mutation Scanning", None))
        self.actionVIP.setText(QCoreApplication.translate("MainWindow", u"RosettaVIP", None))
        self.actionSuper.setText(QCoreApplication.translate("MainWindow", u"Supercharge", None))
        self.actionMS.setText(QCoreApplication.translate("MainWindow", u"Manually Specified", None))
        self.actionHome.setText(QCoreApplication.translate("MainWindow", u"Home", None))
        self.actionAbout.setText(QCoreApplication.translate("MainWindow", u"About", None))
        self.actionWork.setText(QCoreApplication.translate("MainWindow", u"Workspace", None))
        self.actionContact.setText(QCoreApplication.translate("MainWindow", u"Contact", None))
        self.actionSetting.setText(QCoreApplication.translate("MainWindow", u"Setting", None))
        self.VIPButton.setText(QCoreApplication.translate("MainWindow", u"RosettaVIP", None))
        self.SuperButton.setText(QCoreApplication.translate("MainWindow", u"Supercharge", None))
        self.MSButton.setText(QCoreApplication.translate("MainWindow", u"Manually Specified", None))
        self.PSMButton.setText(QCoreApplication.translate("MainWindow", u"Point Mutation Scanning", None))
        self.menuHome.setTitle(QCoreApplication.translate("MainWindow", u"Home", None))
        self.menuAbout.setTitle(QCoreApplication.translate("MainWindow", u"About", None))
        self.menuSubmit.setTitle(QCoreApplication.translate("MainWindow", u"Submit", None))
        self.menuWorkspace.setTitle(QCoreApplication.translate("MainWindow", u"Workspace", None))
        self.menuContact.setTitle(QCoreApplication.translate("MainWindow", u"Contact", None))
        self.menuSetting.setTitle(QCoreApplication.translate("MainWindow", u"Setting", None))
    # retranslateUi

    def loadAndSetStyle(self, widget, styleFileName):
        """load qss file"""
        styleFile = QFile(styleFileName)
        if styleFile.open(QFile.ReadOnly | QFile.Text):
            stream = QTextStream(styleFile)
            widget.setStyleSheet(stream.readAll())


if __name__ == '__main__':
    app = QApplication([])

    mainwindow = QMainWindow()

    ui = Ui_MainWindow()
    ui.setupUi(mainwindow)

    mainwindow.show()
    # sys.exit(app.exec_())
    app.exec_()