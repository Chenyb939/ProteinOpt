# -*- coding: utf-8 -*-
import os
import sys
from utils import process
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *


class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")

        Form.resize(900, 700)
        font = QFont("Arial", 12)
        QApplication.setFont(font)

        self.textBrowser = QTextBrowser(Form)
        self.textBrowser.setObjectName(u"textBrowser")
        self.textBrowser.setGeometry(QRect(50, 50, 800, 600))
        self.textBrowser.setStyleSheet("background-color: transparent; border: none;")

        self.retranslateUi(Form)


        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.textBrowser.setText(QCoreApplication.translate("Form", u"School of Information Science and Technology\n"
"Institution of Computational Biology\n"
"Northeast Normal University\n"
"Changchun 130117 China\n"
"\n"
"zilin.ren@outlook.com \n"
"chenyb939@nenu.edu.cn", None))
    # retranslateUi

if __name__ == '__main__':
    app = QApplication(sys.argv)

    mainwindow = QMainWindow()
    ui = Ui_Form()
    ui.setupUi(mainwindow)
    mainwindow.show()
    sys.exit(app.exec_())