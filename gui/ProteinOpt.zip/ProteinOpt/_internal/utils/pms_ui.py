import sys
import os
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtSql import *
import uuid

BASE_DIR =os.path.dirname(os.path.realpath(sys.argv[0]))
class SuccessDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Success")
        self.setFixedSize(400, 200)

        layout = QVBoxLayout()
        label = QLabel("Submission successful.")
        label.setAlignment(Qt.AlignCenter)
        layout.addWidget(label)

        ok_button = QPushButton("OK")
        
        ok_button.clicked.connect(self.accept)
        layout.addWidget(ok_button)

        self.setLayout(layout)


class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(900, 700)
        font = QFont("Arial", 12)
        QApplication.setFont(font)

        self.gridLayoutWidget = QWidget(Form)
        self.gridLayoutWidget.setObjectName(u"gridLayoutWidget")
        self.gridLayoutWidget.setGeometry(QRect(80, 20, 800, 600))
        self.input_layout = QGridLayout(self.gridLayoutWidget)
        self.input_layout.setObjectName(u"input_layout")
        self.input_layout.setSizeConstraint(QLayout.SetFixedSize)
        self.input_layout.setHorizontalSpacing(100)
        self.input_layout.setVerticalSpacing(20)
        self.input_layout.setContentsMargins(0, 0, 0, 0)

        self.name = QLabel(self.gridLayoutWidget)
        self.name.setObjectName(u"name")

        self.input_layout.addWidget(self.name, 1, 0, 1, 1)

        self.name_Edit = QLineEdit(self.gridLayoutWidget)
        self.name_Edit.setObjectName(u"name_Edit")

        self.input_layout.addWidget(self.name_Edit, 2, 0, 1, 1)

        self.PDB = QLabel(self.gridLayoutWidget)
        self.PDB.setObjectName(u"PDB")

        self.input_layout.addWidget(self.PDB, 3, 0, 1, 1)


        self.PDB_button = QPushButton(self.gridLayoutWidget)
        self.PDB_button.setObjectName(u"PDB_button")
        self.PDB_button.setText("Select File")

        self.input_layout.addWidget(self.PDB_button, 4, 0, 1, 1)

        self.chain = QLabel(self.gridLayoutWidget)
        self.chain.setObjectName(u"chain")

        self.input_layout.addWidget(self.chain, 5, 0, 1, 1)

        self.Chain_Edit = QLineEdit(self.gridLayoutWidget)
        self.Chain_Edit.setObjectName(u"Chain_Edit")

        self.input_layout.addWidget(self.Chain_Edit, 6, 0, 1, 1)

        self.seed = QLabel(self.gridLayoutWidget)
        self.seed.setObjectName(u"seed")

        self.input_layout.addWidget(self.seed, 7, 0, 1, 1)

        self.seed_Edit = QLineEdit(self.gridLayoutWidget)
        self.seed_Edit.setObjectName(u"seed_Edit")

        self.input_layout.addWidget(self.seed_Edit, 8, 0, 1, 1)

        self.thread = QLabel(self.gridLayoutWidget)
        self.thread.setObjectName(u"thread")

        self.input_layout.addWidget(self.thread, 9, 0, 1, 1)

        self.thread_Edit = QLineEdit(self.gridLayoutWidget)
        self.thread_Edit.setObjectName(u"thread_Edit")

        self.input_layout.addWidget(self.thread_Edit, 10, 0, 1, 1)

        self.result = QLabel(self.gridLayoutWidget)
        self.result.setObjectName(u"result")

        self.input_layout.addWidget(self.result, 11, 0, 1, 1)

        self.result_Edit = QLineEdit(self.gridLayoutWidget)
        self.result_Edit.setObjectName(u"result_Edit")

        self.input_layout.addWidget(self.result_Edit, 12, 0, 1, 1)

        self.PDB_add = QLabel(self.gridLayoutWidget)
        self.PDB_add.setObjectName(u"PDB_add")

        self.input_layout.addWidget(self.PDB_add, 3, 1, 2, 1)

        self.thread_add = QLabel(self.gridLayoutWidget)
        self.thread_add.setObjectName(u"thread_add")

        self.input_layout.addWidget(self.thread_add, 9, 1, 2, 1)

        self.seed_add = QLabel(self.gridLayoutWidget)
        self.seed_add.setObjectName(u"seed_add")

        self.input_layout.addWidget(self.seed_add, 7, 1, 2, 1)

        self.input_layout.setColumnStretch(0, 10)
        self.submit_Button = QPushButton(Form)
        self.submit_Button.setObjectName(u"submit_Button")
        self.submit_Button.setGeometry(QRect(500, 600, 75, 23))
        self.loadAndSetStyle(self.submit_Button, f'{BASE_DIR}/utils/styles_b.qss')
        self.clear_Button = QPushButton(Form)
        self.clear_Button.setObjectName(u"clear_Button")
        self.clear_Button.setGeometry(QRect(600, 600, 75, 23))
        self.loadAndSetStyle(self.clear_Button, f'{BASE_DIR}/utils/styles_g.qss')
        self.back_Button = QPushButton(Form)
        self.back_Button.setObjectName(u"back_Button")
        self.back_Button.setGeometry(QRect(700, 600, 75, 23))
        self.loadAndSetStyle(self.back_Button, f'{BASE_DIR}/utils/styles_g.qss')

        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
        self.submit_Button.clicked.connect(self.save_to_database)
        self.clear_Button.clicked.connect(self.clear_input_text)
        self.PDB_button.clicked.connect(self.get_file_path)

        self.db = QSqlDatabase.addDatabase("QSQLITE")
        self.db.setDatabaseName("tasks.db")
        if not self.db.open():
            QMessageBox.critical(None, "Cannot Open Database",
                                 "Unable to establish a database connection.\n"
                                 "The database file cannot be opened.\n"
                                 f"{self.db.lastError().text()}")

        query = QSqlQuery()
        query.exec_("CREATE TABLE IF NOT EXISTS job_data ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE,"
                    "task TEXT,"
                    "status TEXT,"
                    "name TEXT,"
                    "pdb TEXT,"
                    "chain TEXT,"
                    "seed TEXT,"
                    "site TEXT,"
                    "objective TEXT,"
                    "charge TEXT,"
                    "thread TEXT,"
                    "result TEXT)")
        

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.PDB_add.setText(QCoreApplication.translate("Form", u"Files in PDB format only", None))
        self.chain.setText(QCoreApplication.translate("Form", u"The chain to be optimized", None))
        self.thread_add.setText(QCoreApplication.translate("Form", u"Number of cores used at runtime", None))
        self.thread.setText(QCoreApplication.translate("Form", u"The number of threads", None))
        self.result.setText(QCoreApplication.translate("Form", u"The number of optimization results", None))
        self.seed.setText(QCoreApplication.translate("Form", u"The mutation amino acid", None))
        self.seed_add.setText(QCoreApplication.translate("Form", u"The amino acid position with the most\nsignificant decrease in ΔREU will be\nselected based on the number of seeds", None))
        self.PDB.setText(QCoreApplication.translate("Form", u"PDB structure to submit", None))
        self.name.setText(QCoreApplication.translate("Form", u"Job Name", None))
        self.submit_Button.setText(QCoreApplication.translate("Form", u"Submit", None))
        self.clear_Button.setText(QCoreApplication.translate("Form", u"Clear", None))
        self.back_Button.setText(QCoreApplication.translate("Form", u"Back", None))

    def get_file_path(self):
        file_dialog = QFileDialog()
        file_path, _ = file_dialog.getOpenFileName(None, "Select PDB File")  # 获取文件路径
        if file_path:
            file_info = QFileInfo(file_path)
            file_name = file_info.fileName()
            self.PDB_button.setText(file_name)
            self.PDB_button.setProperty("file_path", file_path)


    def save_to_database(self):
        name = self.name_Edit.text()
        pdb = self.PDB_button.property("file_path")
        chain = self.Chain_Edit.text()
        seed = self.seed_Edit.text()
        thread = self.thread_Edit.text()
        result = self.result_Edit.text()


        if not self.is_number(seed):
            error_dialog = ErrorDialog("Seed must be a number.")
            error_dialog.exec_()
            return
        
        if not self.is_number(thread):
            error_dialog = ErrorDialog("Threads must be a number.")
            error_dialog.exec_()
            return

        if not self.is_number(result):
            error_dialog = ErrorDialog("Results must be a number.")
            error_dialog.exec_()
            return

        unique_id = uuid.uuid4()

        query = QSqlQuery()
        query.prepare("INSERT INTO job_data (task, status,name, pdb, chain, seed, thread, result) "
                      "VALUES (?, ?, ?, ?, ?, ?, ?,?)")
        query.addBindValue("pms")
        query.addBindValue("waiting")
        query.addBindValue(name)
        query.addBindValue(pdb)
        query.addBindValue(chain)
        query.addBindValue(seed)
        query.addBindValue(thread)
        query.addBindValue(result)

        if not query.exec_():
            QMessageBox.critical(None, "Database Error",
                                 f"Failed to insert data into database.\n{query.lastError().text()}")
        else:
            dialog = SuccessDialog(self.submit_Button)
            if dialog.exec_() == QDialog.Accepted:
                dialog.close()

        self.clear_input_text()

    def get_input_text(self):
        # 获取文件路径
        file_path = self.PDB_button.property("file_path")

        name = self.name_Edit.text()
        chain = self.Chain_Edit.text()
        seed = self.seed_Edit.text()
        thread = self.thread_Edit.text()
        result = self.result_Edit.text()

        QMessageBox.information(self.PDB_button, "Input Text", f"Name: {name}\n"
                                                               f"PDB: {file_path}\n"
                                                               f"Chain: {chain}\n"
                                                               f"Seed: {seed}\n"
                                                               f"Thread: {thread}\n"
                                                               f"Result: {result}")

        self.name_Edit.clear()
        self.PDB_button.setText("Select File")
        self.Chain_Edit.clear()
        self.thread_Edit.clear()
        self.seed_Edit.clear()
        self.result_Edit.clear()

    def clear_input_text(self):
        self.name_Edit.clear()
        self.PDB_button.setText("Select File")
        self.Chain_Edit.clear()
        self.thread_Edit.clear()
        self.seed_Edit.clear()
        self.result_Edit.clear()

    def loadAndSetStyle(self, widget, styleFileName):
        styleFile = QFile(styleFileName)
        if styleFile.open(QFile.ReadOnly | QFile.Text):
            stream = QTextStream(styleFile)
            widget.setStyleSheet(stream.readAll())

    def is_number(self, s):
        try:
            float(s)
            return True
        except ValueError:
            return False

class ErrorDialog(QMessageBox):
    def __init__(self, message, parent=None):
        super().__init__(parent)
        self.setIcon(QMessageBox.Critical)
        self.setWindowTitle("Error")
        self.setText(message)
        self.setFixedSize(300, 150)
        self.setStandardButtons(QMessageBox.Ok)


if __name__ == '__main__':
    app = QApplication(sys.argv)

    mainwindow = QMainWindow()
    ui = Ui_Form()
    ui.setupUi(mainwindow)
    mainwindow.show()
    sys.exit(app.exec_())
