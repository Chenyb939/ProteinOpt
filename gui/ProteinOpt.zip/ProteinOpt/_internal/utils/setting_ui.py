import sys
import os
import json
import time

from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *

BASE_DIR =os.path.dirname(os.path.realpath(sys.argv[0]))
class SuccessDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Success")
        self.setFixedSize(400, 200)

        layout = QVBoxLayout()
        label = QLabel("Setting saved.")
        label.setAlignment(Qt.AlignCenter)
        layout.addWidget(label)

        ok_button = QPushButton("OK")

        ok_button.clicked.connect(self.accept)
        layout.addWidget(ok_button)

        self.setLayout(layout)


class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(900, 700)
        font = QFont("Arial", 12)
        QApplication.setFont(font)

        self.gridLayoutWidget = QWidget(Form)
        self.gridLayoutWidget.setObjectName(u"gridLayoutWidget")
        self.gridLayoutWidget.setGeometry(QRect(80, 20, 800, 600))
        self.input_layout_2 = QGridLayout(self.gridLayoutWidget)
        self.input_layout_2.setObjectName(u"input_layout_2")
        self.input_layout_2.setSizeConstraint(QLayout.SetFixedSize)
        self.input_layout_2.setHorizontalSpacing(100)
        self.input_layout_2.setVerticalSpacing(20)
        self.input_layout_2.setContentsMargins(0, 0, 0, 0)
        self.ProteinOpt_Edit = QLineEdit(self.gridLayoutWidget)
        self.ProteinOpt_Edit.setObjectName(u"ProteinOpt_Edit")

        self.input_layout_2.addWidget(self.ProteinOpt_Edit, 2, 0, 1, 1)

        self.pythondir = QLabel(self.gridLayoutWidget)
        self.pythondir.setObjectName(u"pythondir")

        self.input_layout_2.addWidget(self.pythondir, 5, 0, 1, 1)

        self.pythondir_add = QLabel(self.gridLayoutWidget)
        self.pythondir_add.setObjectName(u"pythondir_add")

        self.input_layout_2.addWidget(self.pythondir_add, 5, 1, 2, 1)

        self.ProteinOpt_add = QLabel(self.gridLayoutWidget)
        self.ProteinOpt_add.setObjectName(u"ProteinOpt_add")

        self.input_layout_2.addWidget(self.ProteinOpt_add, 1, 1, 2, 1)

        self.Rosettabin_add = QLabel(self.gridLayoutWidget)
        self.Rosettabin_add.setObjectName(u"Rosettabin_add")

        self.input_layout_2.addWidget(self.Rosettabin_add, 3, 1, 2, 1)

        self.work_Edit = QLineEdit(self.gridLayoutWidget)
        self.work_Edit.setObjectName(u"work_Edit")

        self.input_layout_2.addWidget(self.work_Edit, 8, 0, 1, 1)

        self.works = QLabel(self.gridLayoutWidget)
        self.works.setObjectName(u"works")

        self.input_layout_2.addWidget(self.works, 7, 0, 1, 1)

        self.Rosettabin_Edit = QLineEdit(self.gridLayoutWidget)
        self.Rosettabin_Edit.setObjectName(u"Rosettabin_Edit")

        self.input_layout_2.addWidget(self.Rosettabin_Edit, 4, 0, 1, 1)

        self.Rosettabin = QLabel(self.gridLayoutWidget)
        self.Rosettabin.setObjectName(u"Rosettabin")

        self.input_layout_2.addWidget(self.Rosettabin, 3, 0, 1, 1)

        self.work_add = QLabel(self.gridLayoutWidget)
        self.work_add.setObjectName(u"work_add")

        self.input_layout_2.addWidget(self.work_add, 7, 1, 2, 1)

        self.pythondir_Edit = QLineEdit(self.gridLayoutWidget)
        self.pythondir_Edit.setObjectName(u"pythondir_Edit")

        self.input_layout_2.addWidget(self.pythondir_Edit, 6, 0, 1, 1)

        self.Optsoft = QLabel(self.gridLayoutWidget)
        self.Optsoft.setObjectName(u"Optsoft")

        self.input_layout_2.addWidget(self.Optsoft, 1, 0, 1, 1)

        self.input_layout_2.setColumnStretch(0, 10)
        self.submit_Button = QPushButton(Form)
        self.submit_Button.setObjectName(u"submit_Button")
        self.submit_Button.setGeometry(QRect(500, 600, 75, 23))
        self.loadAndSetStyle(self.submit_Button, f'{BASE_DIR}/utils/styles_b.qss')
        self.clear_Button = QPushButton(Form)
        self.clear_Button.setObjectName(u"clear_Button")
        self.clear_Button.setGeometry(QRect(600, 600, 75, 23))
        self.loadAndSetStyle(self.clear_Button, f'{BASE_DIR}/utils/styles_g.qss')
        self.back_Button = QPushButton(Form)
        self.back_Button.setObjectName(u"back_Button")
        self.back_Button.setGeometry(QRect(700, 600, 75, 23))
        self.loadAndSetStyle(self.back_Button, f'{BASE_DIR}/utils/styles_g.qss')

        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
        self.submit_Button.clicked.connect(self.get_input_text)
        self.clear_Button.clicked.connect(self.clear_input_text)

        self.load_data_from_json()

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.pythondir.setText(QCoreApplication.translate("Form", u"Python Directory", None))
        self.pythondir_add.setText(QCoreApplication.translate("Form", u"Python environment directory", None))
        self.ProteinOpt_add.setText(QCoreApplication.translate("Form", u"ProteinOpt bin directory", None))
        self.Rosettabin_add.setText(QCoreApplication.translate("Form", u"Rosetta Bin directory", None))
        self.works.setText(QCoreApplication.translate("Form", u"Work directory", None))
        self.Rosettabin.setText(QCoreApplication.translate("Form", u"Rosetta Bin Directory", None))
        self.work_add.setText(QCoreApplication.translate("Form", u"ProteinOpt work directory", None))
        self.Optsoft.setText(QCoreApplication.translate("Form", u"ProteinOpt Directory", None))
        self.submit_Button.setText(QCoreApplication.translate("Form", u"Submit", None))
        self.clear_Button.setText(QCoreApplication.translate("Form", u"Clear", None))
        self.back_Button.setText(QCoreApplication.translate("Form", u"Back", None))
    # retranslateUi

    def get_input_text(self):
        data = {
            "ProteinOpt": self.ProteinOpt_Edit.text(),
            "Rosettabin": self.Rosettabin_Edit.text(),
            "PythonDir": self.pythondir_Edit.text(),
            "WorkDir": self.work_Edit.text()
        }

        with open('./setting.json', 'w') as json_file:
            json.dump(data, json_file, indent=4)
        # self.clear_input_text()

        dialog = SuccessDialog(self.submit_Button)
        if dialog.exec_() == QDialog.Accepted:
            dialog.close()

    def clear_input_text(self):
        self.ProteinOpt_Edit.clear()
        self.Rosettabin_Edit.clear()
        self.pythondir_Edit.clear()
        self.work_Edit.clear()

    def load_data_from_json(self):
        json_file_path = './setting.json'
        if os.path.isfile(json_file_path):
            with open(json_file_path, 'r') as json_file:
                data = json.load(json_file)
                self.ProteinOpt_Edit.setText(data.get("ProteinOpt", ""))
                self.Rosettabin_Edit.setText(data.get("Rosettabin", ""))
                self.pythondir_Edit.setText(data.get("PythonDir", ""))
                self.work_Edit.setText(data.get("WorkDir", ""))
        else:
            self.clear_input_text()

    def loadAndSetStyle(self, widget, styleFileName):
        styleFile = QFile(styleFileName)
        if styleFile.open(QFile.ReadOnly | QFile.Text):
            stream = QTextStream(styleFile)
            widget.setStyleSheet(stream.readAll())


if __name__ == '__main__':
    app = QApplication(sys.argv)

    mainwindow = QMainWindow()
    ui = Ui_Form()
    ui.setupUi(mainwindow)
    mainwindow.show()
    sys.exit(app.exec_())
