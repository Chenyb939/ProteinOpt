# -*- coding: utf-8 -*-
import os.path
import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from markdown import markdown

BASE_DIR =os.path.dirname(os.path.realpath(sys.argv[0]))
class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(900, 700)
        font = QFont("Arial", 12)
        QApplication.setFont(font)

        self.textBrowser = QTextBrowser(Form)
        self.textBrowser.setObjectName(u"textBrowser")
        self.textBrowser.setGeometry(QRect(50, 50, 800, 600))
        self.textBrowser.setAlignment(Qt.AlignJustify)
        self.textBrowser.setStyleSheet("background-color: transparent; border: none;")
        
        markdown_file = f"{BASE_DIR}/utils/about.md"

        with open(markdown_file, 'r', encoding='utf-8') as file:
            markdown_text = file.read()
            html_text = markdown(markdown_text)
            self.textBrowser.setHtml(html_text)

        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
    # retranslateUi


if __name__ == '__main__':
    app = QApplication(sys.argv)

    mainwindow = QMainWindow()
    ui = Ui_Form()
    ui.setupUi(mainwindow)
    mainwindow.show()
    sys.exit(app.exec_())
