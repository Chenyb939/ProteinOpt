import logging
import sqlite3
import subprocess
import re
from subprocess import Popen, PIPE
import os
import json
import time
import shutil
from pathlib import Path
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtCore import QThread, pyqtSignal, QTimer
import configparser

def command1(command,task_id,log_file_path,db_path):
    try:
        process = Popen(command,stdout=PIPE, stderr=PIPE, shell=True)
        process.wait()
        stdout, stderr = process.communicate()
        print("STDOUT:", stdout.decode())
        print("STDERR:", stderr.decode())
        if process.returncode == 0:
            return True

    except subprocess.CalledProcessError as e:
        print(f"Command 1 fails to run: {e}")
        return False
    except Exception as e:
        print(f"Command 1 fails to run: {e}")
        return False

    finally:
        file=os.path.join(log_file_path,str(task_id)+'.log')
        with open(file, 'a+') as log_file:
            if stdout:
                log_file.write("stdout:\n")
                log_file.write(stdout.decode())
            if stderr:
                log_file.write(f"\nTask {task_id}: Command 1 fails to run,The status was updated to error.")
                log_file.write("stderr:\n")
                log_file.write(stderr.decode())
            if process.returncode == 0:
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                cursor.execute(f"UPDATE job_data SET status = 'Running' WHERE id = '{task_id}';")
                conn.commit()
                conn.close()
                print(f"Task {task_id} :Command 1 is successfully run,The status was updated to running.")
                log_file.write(f"Task {task_id} :Command 1 is successfully run,The status was updated to running.")
            else:
                print(f"\nTask {task_id}: Command 1 fails to run,The status was updated to error.")
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                cursor.execute(f"UPDATE job_data SET status = 'Error' WHERE id = '{task_id}';")
                conn.commit()
                conn.close()

def command2(command,task_id,log_file_path,db_path):
    try:
        process = Popen(command, stdout=PIPE, stderr=PIPE, shell=True)
        process.wait()
        stdout, stderr = process.communicate()
        print("STDOUT:", stdout.decode())
        print("STDERR:", stderr.decode())
        if process.returncode == 0:
            return True

    except subprocess.CalledProcessError as e:
        print(f"执行过程中发生错误: {e}")
        return False
    except Exception as e:
        print(f"未预料的错误: {e}")
        return False

    finally:
        file=os.path.join(log_file_path,str(task_id)+'.log')
        with open(file, 'a+') as log_file:
            if stdout:
                log_file.write("stdout:\n")
                log_file.write(stdout.decode())
            if stderr:
                log_file.write(f"\nTask {task_id}: Command 2 fails to run,The status was updated to error.")
                log_file.write("stderr:\n")
                log_file.write(stderr.decode())
            if process.returncode == 0:
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                cursor.execute(f"UPDATE job_data SET status = 'Running' WHERE id = '{task_id}';")
                conn.commit()
                conn.close()
                print(f"Command 2 is successfully run")
                log_file.write(f"Task {task_id} :Command 2 is successfully run,The status was updated to running.")
            else:
                print(f"\nTask {task_id}: Command 2 fails to run,The status was updated to error.")
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                cursor.execute(f"UPDATE job_data SET status = 'Error' WHERE id = '{task_id}'")
                conn.commit()
                conn.close()

def command3(command,task_id,log_file_path,db_path):
    try:
        process = Popen(command, stdout=PIPE, stderr=PIPE, shell=True)
        process.wait()
        stdout, stderr = process.communicate()
        print("STDOUT:", stdout.decode())
        print("STDERR:", stderr.decode())
        if process.returncode == 0:
            return True

    except subprocess.CalledProcessError as e:
        print(f"执行过程中发生错误: {e}")
        return False
    except Exception as e:
        print(f"未预料的错误: {e}")
        return False

    finally:
        file=os.path.join(log_file_path,str(task_id)+'.log')
        with open(file, 'a+') as log_file:
            if stdout:
                log_file.write("stdout:\n")
                log_file.write(stdout.decode())
            if stderr:
                log_file.write(f"\nTask {task_id}: Command 3 fails to run,The status was updated to error.")
                log_file.write("stderr:\n")
                log_file.write(stderr.decode())
            if process.returncode == 0:
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                cursor.execute(f"UPDATE job_data SET status = 'Done' WHERE id = '{task_id}';")
                conn.commit()
                conn.close()
                print(f"Task {task_id} :Command 3 is successfully run")
                log_file.write(f"Task {task_id} :Command 3 is successfully run,The status was updated to done.")
            else:
                print(f"\nTask {task_id}: Command 3 fails to run,The status was updated to error.")
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                cursor.execute(f"UPDATE job_data SET status = 'Error' WHERE id = '{task_id}'")
                conn.commit()
                conn.close()


def find_and_update_task(path):
    if not os.path.exists(os.path.join(path,"setting.json")):
        print("process: No settings made")
        return 0;

    db_path=os.path.join(path,"tasks.db")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM job_data WHERE status = 'waiting' LIMIT 1")
    task = cursor.fetchone()
    if not task:
        print("no task is waiting")
        return 0;
    else:
        column_names = [description[0] for description in cursor.description]
        task = dict(zip(column_names, task))
    print("Task ID:",task['id'])
    if os.path.exists(os.path.join(path, "setting.json")):
        with open(os.path.join(path,"setting.json"), 'r') as file:
            set = json.load(file)
    soft_dir = set['ProteinOpt']
    python_path=set['PythonDir']
    Rosetta_path=set['Rosettabin']
    work_dir=set['WorkDir']
    upload_path = os.path.join(work_dir,"task",f'{task["id"]}')
    if not os.path.exists(upload_path):
        os.makedirs(upload_path)
    file_path=os.path.join(upload_path,os.path.basename(task["pdb"]))
    shutil.copy(task["pdb"], file_path)
    script_path = os.path.join(soft_dir, 'stab_dp.py')
    log_file_path = os.path.join(work_dir,"log")
    if not os.path.exists(log_file_path):
        os.makedirs(log_file_path)

    if task['task']=='pms':
        command = f'{python_path} {script_path} --job_name {task["id"]} --input_file {file_path} ' \
                  f'--target_chain {task["chain"]} --ntasks {task["thread"]} --num {task["result"]} --python_path {python_path} ' \
                  f'--top_pm_num {task["seed"]} --Rosetta_dir {Rosetta_path} --output_dir {work_dir} --proteinopt_bin {soft_dir+"/bin"}'
    if task['task']=="vip":
        command = f'{python_path}  {script_path} --job_name {task["id"]} --input_file {file_path} ' \
                  f'--target_chain {task["chain"]} --ntasks {task["thread"]} --num {task["result"]} ' \
                  f'--Rosetta_dir {Rosetta_path} --output_dir {work_dir} --proteinopt_bin {soft_dir+"/bin"} --python_path {python_path} '
    if task['task']=="super":
        method=task["objective"][0:-1]
        #print(method)
        command = f'{python_path}  {script_path} --job_name {task["id"]} --input_file {file_path} ' \
                  f'--target_chain {task["chain"]} --ntasks {task["thread"]} --num {task["result"]} ' \
                  f'--super_method {method} --super_target {task["charge"]} --Rosetta_dir {Rosetta_path} ' \
                  f'--output_dir {work_dir} --proteinopt_bin {soft_dir+"/bin"} --python_path {python_path}'
    if task['task']=="pm":
        manally_sites = re.sub(r'([a-zA-Z])\B(\d+)', r'\2', task["site"]).upper()
        #print(manally_sites)
        command = f'{python_path}  {script_path} --job_name {task["id"]} --input_file {file_path} ' \
                  f'--target_chain {task["chain"]} --ntasks {task["thread"]} --num {task["result"]}  --python_path {python_path} ' \
                  f'--in_site {manally_sites} --Rosetta_dir {Rosetta_path} --output_dir {work_dir} --proteinopt_bin {soft_dir+"/bin"}'
    print("command1:",command)
    flag=command1(command,task["id"],log_file_path,db_path)

    if flag:
        os.chdir(os.path.join(work_dir, str(task["id"]), 'snakemake'))
        #print(os.getcwd())
        py_path= Path(python_path)
        conda_path=os.path.join(py_path.parents[3],"bin","activate")
        env_name=py_path.parents[1].name
        print("conda_base_path:",conda_path)
        print("Environment name:",env_name)

        command = f"source {conda_path} {env_name} && bash {work_dir}/{task['id']}/snakemake/preprocess.sh"
        flag=command2(command, task["id"], log_file_path,db_path)

    if flag:
        py_path = Path(python_path)
        conda_path = os.path.join(py_path.parents[3], "bin", "activate")
        env_name = py_path.parents[1].name

        if task['task'] == 'pms':
            command = f"source {conda_path} {env_name} && bash {work_dir}/{task['id']}/snakemake/PMS.sh"
        if task['task'] == "vip":
            command = f"source {conda_path} {env_name} && bash {work_dir}/{task['id']}/snakemake/RosettaVIP.sh"
        if task['task'] == "super":
            command = f"source {conda_path} {env_name} && bash {work_dir}/{task['id']}/snakemake/Supercharge_ref.sh"
        if task['task'] == "pm":
            command = f"source {conda_path} {env_name} && bash {work_dir}/{task['id']}/snakemake/Manual.sh"
        os.chdir(os.path.join(work_dir, str(task["id"]), 'snakemake'))
        flag = command3(command, task["id"], log_file_path, db_path)

    return 0


def main(path):
    #with open("./process_start.txt", 'a+') as logging:
        #logging.write(f"The process starts running")
    print("Background worker run")
    find_and_update_task(path)
    time.sleep(5)
    return 0


class BackgroundWorker(QThread):
    finished = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.stop = False

    def run(self):
        while not self.stop:
            GUI_PATH = os.getcwd()
            main(GUI_PATH)

    def stop_thread(self):
        self.stop = True
        self.wait()

flag=False
if __name__ == "__main__":
    GUI_PATH=os.getcwd()
    main(GUI_PATH)