import os
import sys
import json
import shutil
import time

from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtSql import *
import sqlite3


class Ui_Form(QMainWindow):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(900, 700)
        font = QFont("Arial", 12)
        QApplication.setFont(font)

        self.QTableWidget = QTableWidget(Form)
        self.QTableWidget.setObjectName(u"tableView")
        self.QTableWidget.setGeometry(QRect(20, 20, 860, 660))
        self.QTableWidget.setParent(Form)
        self.QTableWidget.setEditTriggers(QTableWidget.NoEditTriggers)

        self.QTableWidget.setStyleSheet(
            "QTableWidget {border: none; background-color: transparent;}" 
            "QTableWidget::item {border: none;}" 
            "QTableWidget::item:selected {color: blue;}"
        )

        self.QTableWidget.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.QTableWidget.horizontalHeader().setDefaultAlignment(Qt.AlignCenter)
        self.QTableWidget.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)

        self.QTableWidget.setRowCount(0)
        self.QTableWidget.setColumnCount(7)
        self.QTableWidget.setHorizontalHeaderLabels(["Job ID","Job Name", "PDB file", "Opt method", "Status", "Download", "Delete"])
        
        self.load_data_from_dbs()

        self.retranslateUi(Form)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.load_data_from_dbs)
        self.timer.start(5000)  # 10秒刷新一次

        QMetaObject.connectSlotsByName(Form)

        # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Database Table View", None))
        self.QTableWidget.horizontalHeaderItem(0).setText(QCoreApplication.translate("Form", u"Job ID", None))
        self.QTableWidget.horizontalHeaderItem(1).setText(QCoreApplication.translate("Form", u"Job Name", None))
        self.QTableWidget.horizontalHeaderItem(2).setText(QCoreApplication.translate("Form", u"PDB file", None))
        self.QTableWidget.horizontalHeaderItem(3).setText(QCoreApplication.translate("Form", u"Opt method", None))
        self.QTableWidget.horizontalHeaderItem(4).setText(QCoreApplication.translate("Form", u"Status", None))
        self.QTableWidget.horizontalHeaderItem(5).setText(QCoreApplication.translate("Form", u"Download", None))
        self.QTableWidget.horizontalHeaderItem(6).setText(QCoreApplication.translate("Form", u"Action", None))


    def load_data_from_dbs(self):
        #print("Page Reload")
        try:
            self.QTableWidget.setRowCount(0)
            conn = sqlite3.connect("tasks.db")
            cursor = conn.cursor()
            cursor.execute("SELECT name, pdb, status, id, task FROM job_data WHERE status != 'delete'")
            records = cursor.fetchall()
            for record in records:
                # print(record)
                self.add_record_to_table(self.QTableWidget, record[0], record[1], record[2], record[3], record[4])
            self.QTableWidget.resizeRowsToContents()
            self.QTableWidget.resizeColumnsToContents()
            conn.close()
        except sqlite3.Error as e:
            print(e)

    def add_record_to_table(self, table_widget, name, pdb, status, record_id, task):
        # print("record_id:",record_id)
        row_position = table_widget.rowCount()
        table_widget.insertRow(row_position)
        idItem = QTableWidgetItem(str(record_id))
        idItem.setTextAlignment(Qt.AlignCenter)
        table_widget.setItem(row_position, 0, idItem)
        nameItem = QTableWidgetItem(name)
        nameItem.setTextAlignment(Qt.AlignCenter)
        table_widget.setItem(row_position, 1, nameItem)
        file_info = QFileInfo(pdb)
        fileItem = QTableWidgetItem(file_info.fileName())
        fileItem.setTextAlignment(Qt.AlignCenter)
        table_widget.setItem(row_position, 2, fileItem)
        status_item = QTableWidgetItem(status)

        work_fold = self.get_protein_opt_path(record_id)
        #print(work_fold)

        if self.check_success_log(work_fold):
            status_item.setText(" Done ")
        status_item.setTextAlignment(Qt.AlignCenter)
        table_widget.setItem(row_position, 4, status_item)

        download_button = QPushButton("Result")
        download_button.clicked.connect(lambda: self.open_folder(work_fold))
        table_widget.setCellWidget(row_position, 5, download_button)

        delete_button = QPushButton("Delete")
        if task == "pms":
            dbItem = QTableWidgetItem(" Point Mutation Scanning ")
            dbItem.setTextAlignment(Qt.AlignCenter)
            table_widget.setItem(row_position, 3, dbItem)
            delete_button.clicked.connect(lambda: self.delete_record(table_widget, row_position, "tasks.db"))
        elif task == "super":
            dbItem = QTableWidgetItem(" Supercharge ")
            dbItem.setTextAlignment(Qt.AlignCenter)
            table_widget.setItem(row_position, 3, dbItem)
            # table_widget.setItem(row_position, 2, QTableWidgetItem())
            delete_button.clicked.connect(lambda: self.delete_record(table_widget, row_position, "tasks.db"))
        elif task == "vip":
            dbItem = QTableWidgetItem(" RosettaVIP ")
            dbItem.setTextAlignment(Qt.AlignCenter)
            table_widget.setItem(row_position, 3, dbItem)
            # table_widget.setItem(row_position, 2, QTableWidgetItem("RosettaVIP"))
            delete_button.clicked.connect(lambda: self.delete_record(table_widget, row_position, "tasks.db"))
        elif task == "pm":
            dbItem = QTableWidgetItem(" Manually Specified ")
            dbItem.setTextAlignment(Qt.AlignCenter)
            table_widget.setItem(row_position, 3, dbItem)
            # table_widget.setItem(row_position, 2, QTableWidgetItem("Manually Specified"))
            delete_button.clicked.connect(lambda: self.delete_record(table_widget, row_position, "tasks.db"))

        table_widget.setCellWidget(row_position, 6, delete_button)


    def open_folder(self, folder_path):
        # folder_path = QFileInfo(folder_path).absolutePath()
        # print(folder_path)
        QDesktopServices.openUrl(QUrl.fromLocalFile(folder_path))

    def delete_record(self, table_widget, row, db_name):
        record_id_item = table_widget.item(row, 0)
        pid = record_id_item.text()
        print(pid)
        work_folder = self.get_protein_opt_path(pid)

        conn = sqlite3.connect(db_name)
        cursor = conn.cursor()
        cursor.execute(f"UPDATE job_data SET status = 'delete' WHERE id = '{pid}'")
        conn.commit()
        conn.close()

        self.load_data_from_dbs()
        # shutil.rmtree(work_folder)
        
    def get_protein_opt_path(self, record_id):
        if not os.path.exists(os.path.join("./setting.json")):
            print("No settings made")
            return None
        else:
            with open("./setting.json", 'r') as file:
                data = json.load(file)
            work_fold = data['WorkDir']
            folder_name = str(record_id)
            download_fold = os.path.join(work_fold, folder_name)
            return download_fold

    def check_success_log(self, work_folder):
        # work_folder = QFileInfo(work).absolutePath()
        success_log_path = QDir(work_folder).filePath("success.log")
        return QFileInfo(success_log_path).exists()
    

if __name__ == '__main__':
    app = QApplication(sys.argv)

    mainwindow = QMainWindow()
    ui = Ui_Form()
    ui.setupUi(mainwindow)
    mainwindow.show()
    sys.exit(app.exec_())
